package com.fedex.safetnetportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SafetnetportalApplication {

	public static void main(String[] args) {
		SpringApplication.run(SafetnetportalApplication.class, args);
	}

}
