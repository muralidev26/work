/**
 * 
 */
package com.fedex.safetnetportal.auth.model;

/**
 * @author 3820427
 *
 */
public class User {

}
