package com.fedex.safetnetportal.auth.repository;

public class RoleRepository {

}
