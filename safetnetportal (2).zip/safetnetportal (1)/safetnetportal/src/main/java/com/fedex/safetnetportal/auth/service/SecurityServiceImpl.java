/**
 * 
 */
package com.fedex.safetnetportal.auth.service;

/**
 * @author 3820427
 *
 */
public class SecurityServiceImpl implements SecurityService {

}
